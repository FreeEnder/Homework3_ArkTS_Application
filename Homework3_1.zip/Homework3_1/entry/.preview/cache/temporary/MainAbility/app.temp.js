var _63c35725a80490798b1b4472eea01269;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../../Project/Homework3_1/entry/src/main/ets/MainAbility/app.ets?entry":
/*!******************************************************************************************!*\
  !*** ../../../../../../Project/Homework3_1/entry/src/main/ets/MainAbility/app.ets?entry ***!
  \******************************************************************************************/
/***/ (function(__unused_webpack_module, exports) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var _ohos_hilog_1  = globalThis.requireNapi('hilog') || (isSystemplugin('hilog', 'ohos') ? globalThis.ohosplugin.hilog : isSystemplugin('hilog', 'system') ? globalThis.systemplugin.hilog : undefined);
globalThis.exports.default = {
    onCreate() {
        _ohos_hilog_1.info(0x0000, 'testTag', '%{public}s', 'Application onCreate');
    },
    onDestroy() {
        _ohos_hilog_1.info(0x0000, 'testTag', '%{public}s', 'Application onDestroy');
    },
};


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["../../../../../../Project/Homework3_1/entry/src/main/ets/MainAbility/app.ets?entry"](0, __webpack_exports__);
/******/ 	_63c35725a80490798b1b4472eea01269 = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=app.js.map