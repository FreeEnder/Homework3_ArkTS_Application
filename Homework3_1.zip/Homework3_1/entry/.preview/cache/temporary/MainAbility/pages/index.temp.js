var _63c35725a80490798b1b4472eea01269;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../../Project/Homework3_1/entry/src/main/ets/MainAbility/pages/index.ets?entry":
/*!**************************************************************************************************!*\
  !*** ../../../../../../Project/Homework3_1/entry/src/main/ets/MainAbility/pages/index.ets?entry ***!
  \**************************************************************************************************/
/***/ (function(__unused_webpack_module, exports) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
let __generate__Id = 0;
function generateId() {
    return "index_" + ++__generate__Id;
}
var _ohos_promptAction_1  = globalThis.requireNapi('promptAction') || (isSystemplugin('promptAction', 'ohos') ? globalThis.ohosplugin.promptAction : isSystemplugin('promptAction', 'system') ? globalThis.systemplugin.promptAction : undefined);
var _ohos_router_1  = globalThis.requireNapi('router') || (isSystemplugin('router', 'ohos') ? globalThis.ohosplugin.router : isSystemplugin('router', 'system') ? globalThis.systemplugin.router : undefined);
var _ohos_net_http_1  = globalThis.requireNapi('net.http') || (isSystemplugin('net.http', 'ohos') ? globalThis.ohosplugin.net.http : isSystemplugin('net.http', 'system') ? globalThis.systemplugin.net.http : undefined);
var _ohos_data_preferences_1  = globalThis.requireNapi('data.preferences') || (isSystemplugin('data.preferences', 'ohos') ? globalThis.ohosplugin.data.preferences : isSystemplugin('data.preferences', 'system') ? globalThis.systemplugin.data.preferences : undefined);
var _ohos_ability_featureAbility_1  = globalThis.requireNapi('ability.featureAbility') || (isSystemplugin('ability.featureAbility', 'ohos') ? globalThis.ohosplugin.ability.featureAbility : isSystemplugin('ability.featureAbility', 'system') ? globalThis.systemplugin.ability.featureAbility : undefined);
class Index extends View {
    constructor(compilerAssignedUniqueChildId, parent, params, localStorage) {
        super(compilerAssignedUniqueChildId, parent, localStorage);
        this.__message = new ObservedPropertySimple('每日风景图画', this, "message");
        this.__img_link = new ObservedPropertySimple('', this, "img_link");
        this.__img_tag = new ObservedPropertySimple('', this, "img_tag");
        this.img_list = undefined;
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.img_link !== undefined) {
            this.img_link = params.img_link;
        }
        if (params.img_tag !== undefined) {
            this.img_tag = params.img_tag;
        }
        if (params.img_list !== undefined) {
            this.img_list = params.img_list;
        }
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__img_link.aboutToBeDeleted();
        this.__img_tag.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    get img_link() {
        return this.__img_link.get();
    }
    set img_link(newValue) {
        this.__img_link.set(newValue);
    }
    get img_tag() {
        return this.__img_tag.get();
    }
    set img_tag(newValue) {
        this.__img_tag.set(newValue);
    }
    aboutToAppear() {
        _ohos_net_http_1.createHttp().request('https://qqlykm.cn/api/fengjing/index?key=84MhdyhPdOY66ltcJhyukusPAI&type=json', (err, data) => {
            if (!err) {
                let target = JSON.parse(data.result.toString());
                this.img_link = target.data.cover;
                this.img_tag = target.data.tag;
            }
        });
        let context = _ohos_ability_featureAbility_1.getContext();
        let preferences = null;
        let promise = _ohos_data_preferences_1.getPreferences(context, 'mystore');
        promise.then((object) => {
            preferences = object;
            preferences.get('cityList', [{ 'url': '', 'tag': '' }]).then((value) => { this.img_list = this.img_list.concat(value); });
            console.info("Succeeded in getting preferences.");
        }).catch((err) => {
            console.log("Failed to get preferences. code = " + err.code + ", message = " + err.message);
        });
    }
    render() {
        Row.create();
        Row.debugLine("pages/index.ets(41:5)");
        Row.height('100%');
        Column.create();
        Column.debugLine("pages/index.ets(42:7)");
        Column.width('100%');
        Text.create(this.message);
        Text.debugLine("pages/index.ets(43:9)");
        Text.fontSize(40);
        Text.fontColor(Color.Brown);
        Text.textAlign(TextAlign.Center);
        Text.pop();
        Image.create(this.img_link);
        Image.debugLine("pages/index.ets(47:9)");
        Image.width("90%");
        Image.height("85%");
        Text.create(this.img_tag);
        Text.debugLine("pages/index.ets(50:9)");
        Text.fontSize(20);
        Text.fontColor(Color.Black);
        Text.textAlign(TextAlign.Center);
        Text.pop();
        Row.create();
        Row.debugLine("pages/index.ets(54:9)");
        Button.createWithLabel('保存图像');
        Button.debugLine("pages/index.ets(55:11)");
        Button.onClick(() => {
            let context = _ohos_ability_featureAbility_1.getContext();
            let preferences = null;
            let promise = _ohos_data_preferences_1.getPreferences(context, 'mystore');
            promise.then((object) => {
                preferences = object;
                this.img_list.push({ 'url': this.img_link, 'tag': this.img_tag });
                preferences.put('cityList', this.img_list).then(() => {
                    preferences.flush();
                    console.info("Succeeded in putting value of 'fontColor'.");
                }).catch((err) => {
                    console.info("Failed to put value of 'fontColor'. code = " + err.code + ", message = " + err.message);
                });
                console.info("Succeeded in getting preferences.");
            }).catch((err) => {
                console.log("Failed to get preferences. code = " + err.code + ", message = " + err.message);
            });
            _ohos_promptAction_1.showToast({ message: '已保存', duration: 2000 });
        });
        Button.pop();
        Button.createWithLabel('返回主页');
        Button.debugLine("pages/index.ets(76:11)");
        Button.onClick(() => {
            _ohos_router_1.pushUrl({ url: 'pages/imgList',
                params: { img: this.img_list } });
        });
        Button.pop();
        Button.createWithLabel('重新生成');
        Button.debugLine("pages/index.ets(81:11)");
        Button.fontColor(Color.Red);
        Button.onClick(() => _ohos_net_http_1.createHttp().request('https://qqlykm.cn/api/fengjing/index?key=84MhdyhPdOY66ltcJhyukusPAI&type=json', (err, data) => {
            if (!err) {
                let target = JSON.parse(data.result.toString());
                this.img_link = target.data.cover;
                this.img_tag = target.data.tag;
            }
        }));
        Button.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
}
loadDocument(new Index("1", undefined, {}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["../../../../../../Project/Homework3_1/entry/src/main/ets/MainAbility/pages/index.ets?entry"](0, __webpack_exports__);
/******/ 	_63c35725a80490798b1b4472eea01269 = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=index.js.map