var _63c35725a80490798b1b4472eea01269;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../../Project/Homework3_1/entry/src/main/ets/MainAbility/pages/imgList.ets?entry":
/*!****************************************************************************************************!*\
  !*** ../../../../../../Project/Homework3_1/entry/src/main/ets/MainAbility/pages/imgList.ets?entry ***!
  \****************************************************************************************************/
/***/ (function(__unused_webpack_module, exports) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
let __generate__Id = 0;
function generateId() {
    return "imgList_" + ++__generate__Id;
}
var _ohos_promptAction_1  = globalThis.requireNapi('promptAction') || (isSystemplugin('promptAction', 'ohos') ? globalThis.ohosplugin.promptAction : isSystemplugin('promptAction', 'system') ? globalThis.systemplugin.promptAction : undefined);
var _ohos_router_1  = globalThis.requireNapi('router') || (isSystemplugin('router', 'ohos') ? globalThis.ohosplugin.router : isSystemplugin('router', 'system') ? globalThis.systemplugin.router : undefined);
class Home extends View {
    constructor(compilerAssignedUniqueChildId, parent, params, localStorage) {
        super(compilerAssignedUniqueChildId, parent, localStorage);
        this.__message = new ObservedPropertySimple('保存的图片', this, "message");
        this.__img_link = new ObservedPropertyObject(_ohos_router_1.getParams()['img'], this, "img_link");
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.img_link !== undefined) {
            this.img_link = params.img_link;
        }
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__img_link.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    get img_link() {
        return this.__img_link.get();
    }
    set img_link(newValue) {
        this.__img_link.set(newValue);
    }
    aboutToAppear() {
        console.info(this.img_link.length.toString());
    }
    render() {
        Row.create();
        Row.debugLine("pages/imgList.ets(12:5)");
        Row.height('100%');
        Column.create();
        Column.debugLine("pages/imgList.ets(13:7)");
        Column.width('100%');
        Text.create(this.message);
        Text.debugLine("pages/imgList.ets(14:9)");
        Text.fontSize(50);
        Text.textAlign(TextAlign.Center);
        Text.fontColor(Color.Gray);
        Text.pop();
        List.create({ space: 20, initialIndex: 0 });
        List.debugLine("pages/imgList.ets(18:9)");
        List.width('90%');
        List.height('90%');
        List.scrollBar(BarState.On);
        ListItem.create();
        ListItem.debugLine("pages/imgList.ets(19:11)");
        Row.create();
        Row.debugLine("pages/imgList.ets(20:13)");
        Text.create('随机生成风景画');
        Text.debugLine("pages/imgList.ets(21:15)");
        Text.fontColor(Color.Green);
        Text.fontSize(20);
        Text.textAlign(TextAlign.Center);
        Text.width("70%");
        Text.pop();
        Button.createWithLabel('进入');
        Button.debugLine("pages/imgList.ets(26:15)");
        Button.onClick(() => { _ohos_router_1.pushUrl({ url: 'pages/index' }); });
        Button.fontColor(Color.Red);
        Button.pop();
        Row.pop();
        ListItem.pop();
        ForEach.create("2", this, ObservedObject.GetRawObject(this.img_link), (item) => {
            ListItem.create();
            ListItem.debugLine("pages/imgList.ets(32:13)");
            Row.create();
            Row.debugLine("pages/imgList.ets(33:15)");
            Text.create(item.tag);
            Text.debugLine("pages/imgList.ets(34:17)");
            Text.fontColor(Color.Green);
            Text.fontSize(20);
            Text.textAlign(TextAlign.Center);
            Text.width("60%");
            Text.maxLines(2);
            Text.pop();
            Image.create(item.url);
            Image.debugLine("pages/imgList.ets(40:17)");
            Image.height(90);
            Image.width(50);
            Button.createWithLabel('进入');
            Button.debugLine("pages/imgList.ets(43:17)");
            Button.onClick(() => { _ohos_promptAction_1.showToast({ message: "敬请期待", duration: 2000 }); });
            Button.fontColor(Color.Red);
            Button.pop();
            Row.pop();
            ListItem.pop();
        }, item => item.tag);
        ForEach.pop();
        ListItem.create();
        ListItem.debugLine("pages/imgList.ets(49:11)");
        Row.create();
        Row.debugLine("pages/imgList.ets(50:13)");
        Text.create('等待开放');
        Text.debugLine("pages/imgList.ets(51:15)");
        Text.fontColor(Color.Green);
        Text.fontSize(20);
        Text.textAlign(TextAlign.Center);
        Text.width("70%");
        Text.pop();
        Button.createWithLabel('进入');
        Button.debugLine("pages/imgList.ets(56:15)");
        Button.onClick(() => { _ohos_promptAction_1.showToast({ message: "敬请期待", duration: 2000 }); });
        Button.fontColor(Color.Red);
        Button.pop();
        Row.pop();
        ListItem.pop();
        List.pop();
        Column.pop();
        Row.pop();
    }
}
loadDocument(new Home("1", undefined, {}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["../../../../../../Project/Homework3_1/entry/src/main/ets/MainAbility/pages/imgList.ets?entry"](0, __webpack_exports__);
/******/ 	_63c35725a80490798b1b4472eea01269 = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=imgList.js.map